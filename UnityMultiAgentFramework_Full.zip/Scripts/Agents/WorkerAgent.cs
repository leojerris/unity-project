using UnityEngine;

public class WorkerAgent : AgentBase
{
    public override void AssignTask(AgentTask task)
    {
        base.AssignTask(task);
        Debug.Log($"{name} -> {task.Type}");
    }
}
