using UnityEngine;

public class ScoutAgent : AgentBase
{
    public void Discover(Vector3 pos)
    {
        Blackboard.Set("LastResource", pos);
        MessageBus.Publish("ResourceFound", pos);
    }
}
