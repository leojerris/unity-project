public class SoldierAgent : AgentBase
{
}
