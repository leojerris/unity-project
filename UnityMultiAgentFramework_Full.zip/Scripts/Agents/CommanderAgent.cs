using UnityEngine;

public class CommanderAgent : AgentBase
{
    TaskScheduler scheduler = new TaskScheduler();

    protected override void Awake()
    {
        base.Awake();
        MessageBus.Subscribe("ResourceFound", OnResourceFound);
    }

    void OnResourceFound(object msg)
    {
        Vector3 pos = (Vector3)msg;
        scheduler.AddTask(new AgentTask { Type = TaskType.Work, Target = pos, Priority = 10 });
        Debug.Log("Commander created task");
    }
}
