using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    void Start()
    {
        Debug.Log("Full Multi-Agent Framework Loaded");
    }
}
