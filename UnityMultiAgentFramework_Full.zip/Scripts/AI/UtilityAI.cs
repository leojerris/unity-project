public static class UtilityAI
{
    public static float ScoreTask(AgentTask task)
    {
        return task.Priority;
    }
}
