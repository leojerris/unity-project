using UnityEngine;
public class IdleState : IState
{
    public void Enter() { Debug.Log("Enter Idle"); }
    public void Update() { }
    public void Exit() { }
}
