using System.Collections.Generic;
using UnityEngine;

public class ObjectPool<T> where T : Component
{
    Queue<T> pool = new();
    T prefab;

    public ObjectPool(T prefab, int count)
    {
        this.prefab = prefab;
        for (int i = 0; i < count; i++) pool.Enqueue(GameObject.Instantiate(prefab));
    }

    public T Get() => pool.Count > 0 ? pool.Dequeue() : GameObject.Instantiate(prefab);
    public void Release(T obj) => pool.Enqueue(obj);
}
