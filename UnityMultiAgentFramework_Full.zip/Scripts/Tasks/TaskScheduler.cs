using System.Collections.Generic;
using System.Linq;

public class TaskScheduler
{
    readonly List<AgentTask> tasks = new();
    public void AddTask(AgentTask task) => tasks.Add(task);
    public AgentTask GetBestTask() => tasks.OrderByDescending(t => t.Priority).FirstOrDefault();
}
