using System;
using System.Collections.Generic;

public static class MessageBus
{
    static Dictionary<string, Action<object>> listeners = new();

    public static void Subscribe(string key, Action<object> cb) => listeners[key] = listeners.ContainsKey(key) ? listeners[key] + cb : cb;
    public static void Publish(string key, object msg) { if (listeners.ContainsKey(key)) listeners[key]?.Invoke(msg); }
}
