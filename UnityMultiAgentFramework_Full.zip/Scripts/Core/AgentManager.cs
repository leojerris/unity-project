using System.Collections.Generic;
using UnityEngine;

public class AgentManager : MonoBehaviour
{
    public static AgentManager Instance;
    public static bool HasInstance => Instance != null;
    private readonly List<AgentBase> agents = new();

    void Awake() => Instance = this;
    public void Register(AgentBase a) { if (!agents.Contains(a)) agents.Add(a); }
    public void Unregister(AgentBase a) => agents.Remove(a);
    public List<AgentBase> GetAll() => agents;
}
