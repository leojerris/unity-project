using UnityEngine;
using UnityEngine.AI;

public abstract class AgentBase : MonoBehaviour
{
    public string AgentId;
    public float Health = 100f;
    protected NavMeshAgent nav;
    protected StateMachine fsm;
    protected AgentTask currentTask;

    protected virtual void Awake()
    {
        nav = GetComponent<NavMeshAgent>();
        fsm = new StateMachine();
        AgentManager.Instance.Register(this);
    }

    protected virtual void Update()
    {
        fsm.Update();
    }

    public virtual void AssignTask(AgentTask task) => currentTask = task;

    protected virtual void OnDestroy()
    {
        if (AgentManager.HasInstance) AgentManager.Instance.Unregister(this);
    }
}
