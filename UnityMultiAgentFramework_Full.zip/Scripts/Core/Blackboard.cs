using System.Collections.Generic;

public static class Blackboard
{
    static Dictionary<string, object> data = new();
    public static void Set(string key, object value) => data[key] = value;
    public static T Get<T>(string key) => data.ContainsKey(key) ? (T)data[key] : default;
}
