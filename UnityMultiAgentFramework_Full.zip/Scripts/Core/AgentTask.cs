using UnityEngine;

public enum TaskType { Idle, Move, Work, Attack, Scout }

public class AgentTask
{
    public TaskType Type;
    public Vector3 Target;
    public int Priority;
    public object Payload;
}
